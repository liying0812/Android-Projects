package edu.scu.coen268.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FrameExample extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frame_example);
    }
}